#include "MemoryBlock.h"
#include <iostream>

MemoryBlock::MemoryBlock():
    log_block(false) {
}
